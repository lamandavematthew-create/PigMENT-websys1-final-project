(function () {
  "use strict";
  const list = document.querySelector("#report-list");
  if (!list || !window.PigmentDiseaseStore) return;
  const dialog = document.querySelector("#report-detail");
  const detailContent = document.querySelector("#detail-content");
  const detailEmpty = document.querySelector("#detail-empty");
  const detailTitle = document.querySelector("#detail-title");
  const adminRemarks = document.querySelector("#detail-admin-remarks");
  const confirmationDetails = document.querySelector("#detail-confirmation-details");
  const message = document.querySelector("#admin-message");
  const adminCount = document.querySelector("#admin-count");
  const zoneForm = document.querySelector("#zone-form");
  const zoneList = document.querySelector("#zone-list");
  const zoneMessage = document.querySelector("#zone-message");
  const zoneMapElement = document.querySelector("#admin-zone-map");
  let reports = [];
  let zones = [];
  let selectedId = null;
  let zoneMap;
  let draftLayer;
  let savedLayers;

  function dateLabel(value) {
    return value ? new Date(`${value}T00:00:00`).toLocaleDateString("en-PH", { year: "numeric", month: "short", day: "numeric" }) : "Not provided";
  }
  function statusLabel(value) {
    return { pending: "Pending Review", under_review: "Under Review", confirmed: "Confirmed", rejected: "Rejected" }[value] || value;
  }
  function geometryFromLayer(layer) {
    const editable = layer.getLatLngs ? layer : layer.getLayers()[0];
    const coordinates = editable.getLatLngs()[0].map((point) => [point.lng, point.lat]);
    if (coordinates.length && (coordinates[0][0] !== coordinates[coordinates.length - 1][0] || coordinates[0][1] !== coordinates[coordinates.length - 1][1])) coordinates.push(coordinates[0]);
    return { type: "Polygon", coordinates: [coordinates] };
  }

  function escapeHtml(value) { return String(value ?? "").replace(/[&<>"']/g, (ch) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch])); }
  function renderReports() {
    list.replaceChildren(...reports.map((report) => {
      const row = document.createElement("tr");
      row.innerHTML = `<td><button class="table-link" type="button" data-report-id="${report.report_id}">Report #${report.report_id}</button></td><td>${escapeHtml(report.municipality)}, ${escapeHtml(report.barangay)}</td><td>${dateLabel(report.incident_date)}</td><td><span class="status-label">${statusLabel(report.report_status)}</span></td><td><button class="button button-secondary button-small" type="button" data-report-id="${report.report_id}">Inspect</button></td>`;
      return row;
    }));
    adminCount.textContent = `${reports.length} submitted report${reports.length === 1 ? "" : "s"}`;
  }

  function showReport(id) {
    const report = reports.find((item) => item.report_id === id);
    if (!report) return;
    selectedId = id;
    detailTitle.textContent = `Report #${id} · ${report.disease_type}`;
    const status = document.querySelector("#detail-status");
    status.textContent = statusLabel(report.report_status);
    status.dataset.status = report.report_status;
    list.querySelectorAll("tr").forEach(row => row.classList.toggle("is-selected", Number(row.querySelector("[data-report-id]")?.dataset.reportId) === id));
    document.querySelector("#confirmation-section").open = false;
    document.querySelectorAll("#confirmation-section input, #confirmation-section textarea").forEach(field => field.value = "");
    dialog.showModal();
    detailEmpty.hidden = true;
    detailContent.hidden = false;
    document.querySelector("#detail-location").textContent = `${report.municipality}, ${report.barangay}`;
    document.querySelector("#detail-date").textContent = dateLabel(report.incident_date);
    document.querySelector("#detail-reporter").textContent = report.reporter_name || "Farmer";
    document.querySelector("#detail-description").textContent = report.description;
    adminRemarks.value = report.admin_remarks || "";
    message.textContent = "";
    confirmationDetails.value = "";
    const buttons = document.querySelectorAll(".admin-actions [data-action]");
    buttons.forEach(button => {
      const action = button.dataset.action;
      button.disabled = action === "under_review" ? report.report_status !== "pending"
        : action === "confirmed" ? !["pending", "under_review", "confirmed"].includes(report.report_status)
        : action === "publish" ? report.report_status !== "confirmed" || Boolean(report.is_published)
        : report.report_status === "rejected";
    });
  }

  document.querySelector("#close-report-detail").addEventListener("click", () => dialog.close());
  dialog.addEventListener("click", (event) => { if (event.target === dialog) dialog.close(); });
  dialog.addEventListener("close", () => list.querySelectorAll("tr").forEach(row => row.classList.remove("is-selected")));

  async function refresh() {
    try {
      [reports, zones] = await Promise.all([window.PigmentDiseaseStore.loadReports("admin"), window.PigmentDiseaseStore.loadZones("admin")]);
      renderReports();
      renderZones();
      if (zoneMap && window.L) {
        if (savedLayers) savedLayers.remove();
        savedLayers = L.geoJSON(zones.filter(z=>z.geometry).map(z=>({type:'Feature',geometry:z.geometry,properties:{zone_id:z.zone_id}})), {onEachFeature: (feature, layer) => layer.on('click',()=>loadZone(zones.find(z=>z.zone_id===feature.properties.zone_id)))});
        savedLayers.addTo(zoneMap);
      }
      const select=zoneForm.elements.incidentReportId;
      const current=select.value;
      select.replaceChildren(new Option('None', ''));
      reports.filter(r=>r.report_status==='confirmed').forEach(r=>select.add(new Option(`Report #${r.report_id} · ${r.municipality}`,r.report_id)));
      select.value=current;
    } catch (error) {
      message.textContent = error.message;
    }
  }

  list.addEventListener("click", (event) => {
    const target = event.target.closest("[data-report-id]");
    if (target) showReport(Number(target.dataset.reportId));
  });

  document.querySelector(".admin-actions").addEventListener("click", async (event) => {
    const action = event.target.closest("[data-action]")?.dataset.action;
    if (!action || !selectedId) return;
    const report = reports.find((item) => item.report_id === selectedId);
    if (!report) return;
    const status = action === "publish" || action === "confirmed" ? "confirmed" : action === "under_review" ? "under_review" : "rejected";
    const remarks = adminRemarks.value.trim();
    if (action === "rejected" && remarks.length < 5) { message.textContent = "Provide a reason for rejection (at least five characters)."; return; }
    if (action === "under_review" && !["pending", "under_review"].includes(report.report_status)) {
      message.textContent = "Only pending reports can be accepted for review."; return;
    }
    if (action === "confirmed" && !["pending", "under_review", "confirmed"].includes(report.report_status)) {
      message.textContent = "Rejected reports cannot be confirmed without reopening review."; return;
    }
    if (!window.confirm(`Apply ${action.replaceAll('_', ' ')} to Report #${selectedId}?`)) return;
    let confirmation = null;
    if (action === "confirmed") {
      confirmation = {
        confirmed_by_name: document.querySelector("#confirmed-by").value.trim(),
        designation: document.querySelector("#confirmation-designation").value.trim(),
        organization: document.querySelector("#confirmation-organization").value.trim(),
        confirmation_date: document.querySelector("#confirmation-date").value,
        reference_number: document.querySelector("#confirmation-reference").value.trim(),
        confirmation_notes: confirmationDetails.value.trim()
      };
      if (!confirmation.confirmed_by_name || !confirmation.designation || !confirmation.organization || !confirmation.confirmation_date) {
        document.querySelector("#confirmation-section").open = true;
        message.textContent = "Enter complete authorized veterinary confirmation details."; return;
      }
    }
    if (action === "publish" && report.report_status !== "confirmed") { message.textContent = "Record verified confirmation before publishing."; return; }
    try {
      await window.PigmentDiseaseStore.updateReport(selectedId, {
        report_status: status,
        admin_remarks: remarks,
        confirmation,
        is_published: action === "publish"
      });
      await refresh();
      showReport(selectedId);
      message.textContent = action === "publish" ? "Verified report published." : `Report marked ${statusLabel(status)}.`;
    } catch (error) {
      message.textContent = error.message;
    }
  });

  function buttonZone(cell, text, handler) { const button=document.createElement('button'); button.type='button'; button.className='button button-secondary button-small'; button.textContent=text; button.addEventListener('click',handler); cell.append(button); }
  function renderZones() {
    zoneList.replaceChildren(...zones.map((zone) => {
      const row = document.createElement("tr");
      const edit = document.createElement("button");
      edit.className = "button button-secondary button-small";
      edit.type = "button";
      edit.textContent = "Edit";
      edit.addEventListener("click", () => loadZone(zone));
      const cell = document.createElement("td");
      cell.append(edit);
      if (!zone.is_published) {
        const publish = document.createElement("button");
        publish.className = "button button-primary button-small";
        publish.type = "button";
        publish.textContent = "Publish";
        publish.addEventListener("click", () => { if (window.confirm('Publish this zone? An officially confirmed linked incident is required.')) updateZone(zone, true); });
        cell.append(publish);
      }
      row.innerHTML = `<td><strong>${escapeHtml(zone.zone_name)}</strong></td><td>${escapeHtml(zone.municipality)}, ${escapeHtml(zone.barangay || "")}</td><td>${escapeHtml(zone.disease_type)}</td><td>${escapeHtml(zone.severity)}</td><td>${zone.is_published ? "Published" : "Unpublished"}</td>`;
      if (zone.is_published) { buttonZone(cell, 'Unpublish', () => updateZone(zone, false)); }
      buttonZone(cell, 'Resolve', () => updateZone(zone, false, 'resolved'));
      row.append(cell);
      return row;
    }));
  }

  function loadZone(zone) {
    if (!zone) return;
    if (zoneMap && window.L && zone.geometry) {
      if (draftLayer) zoneMap.removeLayer(draftLayer);
      draftLayer = L.geoJSON(zone.geometry).getLayers()[0];
      draftLayer.addTo(zoneMap);
      if (draftLayer.pm) draftLayer.pm.enable();
      draftLayer.on('pm:edit',()=>{zoneForm.elements.geometry.value=JSON.stringify(geometryFromLayer(draftLayer));});
      zoneMap.fitBounds(draftLayer.getBounds());
    }
    zoneForm.hidden = false;
    zoneForm.elements.zoneId.value = zone.zone_id;
    zoneForm.elements.name.value = zone.zone_name;
    zoneForm.elements.municipality.value = zone.municipality;
    zoneForm.elements.barangay.value = zone.barangay || "";
    zoneForm.elements.diseaseType.value = zone.disease_type;
    zoneForm.elements.severity.value = zone.severity;
    zoneForm.elements.status.value = zone.zone_status === "suspected" ? "monitoring" : zone.zone_status;
    zoneForm.elements.description.value = zone.description || "";
    zoneForm.elements.geometry.value = JSON.stringify(zone.geometry);
    zoneForm.elements.isPublished.checked = Boolean(zone.is_published);
    zoneForm.elements.incidentReportId.value = zone.report_id || "";
    zoneMessage.textContent = "Update the zone details or draw a new boundary before saving.";
  }

  async function updateZone(zone, published, status = zone.zone_status) {
    try {
      await window.PigmentDiseaseStore.saveZone({
        zone_id: zone.zone_id,
        zone_name: zone.zone_name,
        disease_type: zone.disease_type,
        municipality: zone.municipality,
        barangay: zone.barangay || "",
        severity: zone.severity,
        zone_status: status,
        description: zone.description || "",
        report_id: zone.report_id,
        geometry: zone.geometry,
        is_published: published
      });
      zoneMessage.textContent = published ? "Zone published." : "Zone updated.";
      await refresh();
    } catch (error) {
      zoneMessage.textContent = error.message;
    }
  }

  zoneForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!zoneForm.reportValidity()) return;
    const values = Object.fromEntries(new FormData(zoneForm).entries());
    try {
      await window.PigmentDiseaseStore.saveZone({
        zone_id: values.zoneId || null,
        zone_name: values.name,
        disease_type: values.diseaseType,
        municipality: values.municipality,
        barangay: values.barangay,
        severity: values.severity,
        zone_status: values.status,
        description: values.description,
        geometry: JSON.parse(values.geometry || "null"),
        report_id: values.incidentReportId || null,
        is_published: Boolean(zoneForm.elements.isPublished.checked)
      });
      zoneForm.hidden = true;
      zoneMessage.textContent = "Zone saved.";
      await refresh();
    } catch (error) {
      zoneMessage.textContent = error.message;
    }
  });

  document.querySelector("#cancel-zone").addEventListener("click", () => {
    zoneForm.reset();
    zoneForm.hidden = true;
    if (draftLayer) {
      zoneMap.removeLayer(draftLayer);
      draftLayer = null;
    }
  });

  if (zoneMapElement && window.L) {
    zoneMap = L.map(zoneMapElement).setView([13.43, 121.96], 10);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 18, attribution: "&copy; OpenStreetMap contributors" }).addTo(zoneMap);
    if (zoneMap.pm) {
      zoneMap.pm.addControls({ position: "topleft", drawText: false, drawCircle: false, drawCircleMarker: false, drawMarker: false, drawPolyline: false, drawRectangle: false });
      zoneMap.on("pm:create", (event) => {
        if (draftLayer) zoneMap.removeLayer(draftLayer);
        draftLayer = event.layer;
        zoneForm.hidden = false;
        zoneForm.elements.geometry.value = JSON.stringify(geometryFromLayer(draftLayer));
        zoneMessage.textContent = "Boundary drawn. Complete the form to save it.";
      });
      zoneMap.on("pm:edit", () => {
        if (draftLayer) zoneForm.elements.geometry.value = JSON.stringify(geometryFromLayer(draftLayer));
      });
    }
  }
  window.PigmentAuth.requireAuth({adminOnly:true}).then((user) => {
    if (!user) return;
    refresh().then(() => {
      const requested = Number(new URLSearchParams(window.location.search).get('report'));
      if (requested && reports.some(r => r.report_id === requested)) showReport(requested);
    });
  });
}());
